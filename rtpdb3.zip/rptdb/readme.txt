
��ַ�� http://localhost:8080/rptdb/index
���ݿ������ļ���/src/jdbc.properties
sql��
create table rptdb.t_depot_area
(
 D_NAME                                             VARCHAR2(200),
 D_AREA                                             VARCHAR2(2000),
 D_CAPACITY                                         NUMBER(16,4),
 D_COORDINATE                                       VARCHAR2(2000),
 D_DATE                                             DATE);
