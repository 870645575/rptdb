package com.ldw;

import java.io.IOException;

import Controler.Map_API;

public class Test {

    public static void main(String[] args) throws IOException {  
        //String[] o = Map_API.getCoordinate("?");  
        //String[] o1 = Map_API.getAddr("200","200"); 
    	//String[] o = Map_API.getCoordinate("shenzhen"); 
        String[] o = Map_API.getCoordinate("万海大厦A座");  
        String[] o1 = Map_API.getAddr(o[0], o[1]);  
        
        System.out.println("经度："+o[0]);  
        System.out.println("纬度："+o[1]);  
        System.out.println("城市："+o1[0]);  
        System.out.println("区域："+o1[1]);  
        
    }  

}
