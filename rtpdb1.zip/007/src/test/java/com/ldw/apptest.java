package com.ldw;

import java.util.ArrayList;

import Enterties.depotEntity;

public class apptest {

	public static void main(String[] args) {
		App app = new App();

		//app.DeleteData("");
		//app.UpdateData();
		ArrayList<depotEntity> dd=app.SelectData();
		for (int i = 0; i < dd.size(); i++) {
			String string = dd.get(i).toString();
			System.out.println(i+" "+string);
		}
		//depotEntity a=new depotEntity("null","万海大厦A座",1000);
		//System.out.println(a);
		//app.AddData(a);
		//app.DeleteData("null");
		//app.DeleteData(a);
	}

}
