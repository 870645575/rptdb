package com.ldw;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Enterties.depotEntity;


public class App {
	private static String USERNAMR = "rptdb";
	private static String PASSWORD = "rptdb1234";
	private static String DRVIER = "oracle.jdbc.OracleDriver";
	private static String URL = "jdbc:oracle:thin:@10.37.0.5:1521:ygwdb";

	// 创建一个数据库连接
	Connection connection = null;
    PreparedStatement pstm = null;
    ResultSet rs = null;

	public Connection getConnection() {	
		try {
			Class.forName(DRVIER);
			connection = DriverManager.getConnection(URL, USERNAMR, PASSWORD);
			//System.out.println("成功连接数据库");
		} catch (ClassNotFoundException e) {
			throw new RuntimeException("class not find !", e);
		} catch (SQLException e) {
			throw new RuntimeException("get connection error!", e);
		}

		return connection;
	}
	public void AddData(depotEntity d) {
        connection = getConnection();
        String sqlStr = "insert into t_depot_area values(?,?,?,?,?)";
        try {
            // 执行插入数据操作
            pstm = connection.prepareStatement(sqlStr);
            pstm.setString(1, d.getName());
            pstm.setString(2,d.getArea() );
            pstm.setInt(3, d.getCapacity());
            pstm.setString(4,d.getCoordinate());
            pstm.setDate(5, d.getCreateTime());
            pstm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ReleaseResource();
        }
    }
	/*
    public void UpdateData(String stuName, int gender, int age, String address) {
        connection = getConnection();
        String sql = "select id from student where 1 = 1 and stu_name = ?";
        String sqlStr = "update student set stu_name=?,gender=?,age=?,address=? where id=?";
        int count = 0;

        try {
            // 计算数据库student表中数据总数
            pstm = connection.prepareStatement(sql);
            pstm.setString(1, stuName);
            rs = pstm.executeQuery();
            while (rs.next()) {
                count = rs.getInt(1);
                System.out.println(rs.getInt(1));
            }
            // 执行插入数据操作
            pstm = connection.prepareStatement(sqlStr);
            pstm.setString(1, stuName);
            pstm.setInt(2, gender);
            pstm.setInt(3, age);
            pstm.setString(4, address);
            pstm.setInt(5, count);
            pstm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ReleaseResource();
        }
    }
    */
	public ArrayList<depotEntity> SelectData() {
        connection = getConnection();
        String sql = "select * from t_depot_area";
        ArrayList<depotEntity> dd=new ArrayList<depotEntity>();
        depotEntity depotEntity=null;
        try {
        	pstm=connection.prepareStatement(sql);
        	rs = pstm.executeQuery();
            while (rs.next()) {
                String name = rs.getString("d_name");
                String area = rs.getString("d_area");
                int capacity = rs.getInt("d_capacity");
                String coordinate = rs.getString("d_coordinate");
                Date createTime = rs.getDate("d_date");
                depotEntity=new depotEntity(name, area, capacity, coordinate, createTime);
                dd.add(depotEntity);
                //System.out.println(depotEntity.toString());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ReleaseResource();
        }

		return dd;
    }
	public void ReleaseResource() {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (pstm != null) {
            try {
                pstm.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
	public void DeleteData(String d_name) {
        connection = getConnection();
        String sqlStr = "delete from t_depot_area where d_name=?";
        //System.out.println(d_name);
        try {
            // 执行删除数据操作
            pstm = connection.prepareStatement(sqlStr);
            pstm.setString(1, d_name);
            pstm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ReleaseResource();
        }
    }
	public void DeleteData(depotEntity d) {
        connection = getConnection();
        String sqlStr = "delete from t_depot_area where d_name=? and d_area=? and "
        		+ "d_capacity=? and d_coordinate=? and d_date=?";
        try {
            // 执行删除数据操作
            pstm = connection.prepareStatement(sqlStr);
            pstm.setString(1, d.getName());
            pstm.setString(2,d.getArea() );
            pstm.setInt(3, d.getCapacity());
            pstm.setString(4,d.getCoordinate());
            pstm.setDate(5, d.getCreateTime());
            pstm.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            ReleaseResource();
        }
    }
}
